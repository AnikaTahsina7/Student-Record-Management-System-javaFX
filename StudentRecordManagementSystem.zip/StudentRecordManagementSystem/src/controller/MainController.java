package controller;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.Student;

public class MainController {
	@FXML
	private TextField txtSearch;
	@FXML
	private TextField txtName;
	@FXML
	private TextField txtId;
	@FXML
	private TextField txtDepartment;
	@FXML
	private TextField txtEmail;
	@FXML
	private TextField txtCgpa;
	@FXML
	private TableView<Student> table;
	@FXML
	private TableColumn<Student, String> colName;
	@FXML
	private TableColumn<Student, String> colId;
	@FXML
	private TableColumn<Student, String> colDepartment;
	@FXML
	private TableColumn<Student, String> colEmail;
	@FXML
	private TableColumn<Student, Double> colCgpa;
	private ObservableList<Student> studentList = FXCollections.observableArrayList();

	@FXML
	private void initialize() {
		colName.setCellValueFactory(new PropertyValueFactory<>("name"));
		colId.setCellValueFactory(new PropertyValueFactory<>("id"));
		colDepartment.setCellValueFactory(new PropertyValueFactory<>("department"));
		colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
		colCgpa.setCellValueFactory(new PropertyValueFactory<>("cgpa"));
		table.setItems(studentList);
	}

	@FXML
	private void addStudent() {
		try {
			Student student = new Student(txtName.getText(), txtId.getText(), txtDepartment.getText(),
					txtEmail.getText(), Double.parseDouble(txtCgpa.getText()));
			studentList.add(student);
			clearFields();
		} catch (NumberFormatException e) {
			System.out.println("Invalid CGPA value!");
		}
	}

	@FXML
	private void updateStudent() {
		Student selected = table.getSelectionModel().getSelectedItem();
		if (selected != null) {
			selected.setName(txtName.getText());
			selected.setId(txtId.getText());
			selected.setDepartment(txtDepartment.getText());
			selected.setEmail(txtEmail.getText());
			try {
				selected.setCgpa(Double.parseDouble(txtCgpa.getText()));
			} catch (NumberFormatException e) {
				System.out.println("Invalid CGPA value!");
			}
			table.refresh();
		}
	}

	@FXML
	private void deleteStudent() {
		Student selected = table.getSelectionModel().getSelectedItem();
		if (selected != null) {
			studentList.remove(selected);
		}
	}

	@FXML
	private void searchStudent() {
		String keyword = txtSearch.getText().toLowerCase();
		if (keyword.isEmpty()) {
			table.setItems(studentList); // Show all if search is empty
		} else {
			ObservableList<Student> filteredList = FXCollections.observableArrayList();
			for (Student s : studentList) {
				if (s.getName().toLowerCase().contains(keyword) || s.getId().toLowerCase().contains(keyword)
						|| s.getDepartment().toLowerCase().contains(keyword)) {
					filteredList.add(s);
				}
			}
			table.setItems(filteredList);
		}
	}

	private void clearFields() {
		txtName.clear();
		txtId.clear();
		txtDepartment.clear();
		txtEmail.clear();
		txtCgpa.clear();
	}
}
