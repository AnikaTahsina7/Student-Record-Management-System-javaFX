package model;

public class Student {
	private String Name;
	private String Id;
	private String Department;
	private String Email;
	private double Cgpa;

	public Student() {

	}

	public Student(String name, String id, String department, String email, double cgpa) {
	
		Name = name;
		Id = id;
		Department = department;
		Email = email;
		Cgpa = cgpa;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getDepartment() {
		return Department;
	}

	public void setDepartment(String department) {
		Department = department;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public double getCgpa() {
		return Cgpa;
	}

	public void setCgpa(double cgpa) {
		Cgpa = cgpa;
	}

	
}
